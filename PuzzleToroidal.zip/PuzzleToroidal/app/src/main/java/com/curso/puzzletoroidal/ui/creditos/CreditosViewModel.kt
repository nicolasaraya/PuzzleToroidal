package com.curso.puzzletoroidal.ui.creditos

import androidx.lifecycle.ViewModel

class CreditosViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
